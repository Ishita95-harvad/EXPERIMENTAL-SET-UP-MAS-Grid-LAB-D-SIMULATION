# Deployment Guide

This folder contains scripts and configurations for deploying the MAS system to cloud/local environments.
